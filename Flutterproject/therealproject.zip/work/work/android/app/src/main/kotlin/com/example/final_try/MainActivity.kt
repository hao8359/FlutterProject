package com.example.final_try

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
